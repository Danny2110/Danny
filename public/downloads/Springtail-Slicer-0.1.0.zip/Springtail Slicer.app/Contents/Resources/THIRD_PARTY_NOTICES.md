# Third-party notices

Springtail Slicer bundles a modified build of PrusaSlicer's slicing core and
statically links the libraries below. The full corresponding source for the
PrusaSlicer fork is in `engine-src/`; the build configuration is in
`build-engine.sh` and `build-deps.sh`.

| Component | Version | License |
|---|---|---|
| PrusaSlicer / libslic3r | 2.9.6 | AGPL-3.0-or-later |
| Boost | 1.83.0 | Boost Software License 1.0 |
| oneTBB | 2021.5.0 | Apache-2.0 |
| CGAL | 5.6.2 | LGPL-3.0-or-later (parts GPL-3.0-or-later) |
| GMP | 6.2.1 | LGPL-3.0-or-later |
| MPFR | 4.2.1 | LGPL-3.0-or-later |
| OpenVDB | Prusa fork (2022) | MPL-2.0 |
| OpenEXR / Imath | 2.5.5 | BSD-3-Clause |
| Blosc | 1.21.x | BSD-3-Clause |
| Qhull | 8.1-alpha3 | Qhull License (see upstream) |
| NLopt | 2.5.0 | MIT / LGPL-2.1 |
| nlohmann/json | 3.12.0 | MIT |
| cereal | 1.3.0 | BSD-3-Clause |
| Eigen | 3.3.7 | MPL-2.0 |
| libbgcode | Prusa fork | AGPL-3.0 |
| heatshrink | 0.4.x | ISC |
| libjpeg-turbo | 3.0.1 | BSD-3-Clause / IJG |
| libpng | 1.6.x | libpng-2.0 |
| zlib | 1.2.12 (macOS SDK) | zlib |
| Expat | 2.4.3 | MIT |
| Z3 | 4.13.x | MIT |
| Catch2 | 3.8 | BSL-1.0 |

Springtail's Swift sources are original work, distributed under AGPL-3.0-or-later
to match the combined work.

The AnkerMake M5/M5C profiles in `engine-src/resources/profiles/Anker*` come from
PrusaSlicer's bundled vendor profiles and remain under their original licenses.
